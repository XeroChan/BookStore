package com.example.bookstorespringapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreSpringApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookstoreSpringApiApplication.class, args);
    }

}
